이 폴더는 기본적으로 JassHelper에서 //! import 또는 //! loadstructs 또는 외부 도구를 사용할때 검색되는 폴더로 사용됩니다.

jasshelper\jasshelpermanual.html 에서 더 많은 정보를 확인하세요.